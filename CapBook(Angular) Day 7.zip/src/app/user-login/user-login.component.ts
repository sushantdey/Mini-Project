import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Profile } from '../profile';


@Component({
  /* template: ` 
  <div> 
    <h2>Data from UserLoginComponent: {{ profile }} </h2> 
    <input [(ngModel)] = profile /> 
    <br><br> 
    <a [routerLink]="['/userProfile']"> </a> 
  </div> 
  `, */
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  profile:Profile;
  /* get profile():Profile { 
    return this.capBookService.profile;
  } 
  set profile(profile: Profile) { 
    this.capBookService.profile=profile; 
  }  */
  errorMessage:string;
  message:string;
  loginForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private capBookService:CapBookService,private route:ActivatedRoute,private router:Router ) { }

  onSubmit():void{
    console.log("In OnSubmit")
    this.capBookService.userLogin(this.loginForm).subscribe(
      profile=>{
        this.profile=profile;
        sessionStorage.setItem('profile', JSON.stringify(profile));
        this.router.navigate(['/userProfile',profile]);
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
        alert("Please enter valid credentials");
        
        
      }
      )
      
  }
  
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    })
  }

}
