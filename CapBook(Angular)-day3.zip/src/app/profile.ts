export interface Profile {
    emailId:string;
    password:string;
    firstName:string;
    lastName:string;
    dateOfBirth:string;
    gender:string;
    userBio:string;
    relationshipStatus:string;
    dateOfJoining:string;
    designation:string;
    currentCity:string;
    homeTown:string;
    highestEducation:string
}
