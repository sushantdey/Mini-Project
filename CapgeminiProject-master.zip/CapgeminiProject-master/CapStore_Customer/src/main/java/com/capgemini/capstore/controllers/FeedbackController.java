package com.capgemini.capstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Feedback;
import com.capgemini.capstore.services.FeedbackServices;

@RestController
public class FeedbackController {
	
	@Autowired
	FeedbackServices services;
	
	@RequestMapping(value="/addFeedback",method=RequestMethod.POST)
	public Feedback addFeedback(@RequestBody Feedback feedBack)
	{
		Feedback feedback=services.addFeedback(feedBack);
		return feedback;
		
	}
	
	
	@RequestMapping(value="/getFeedback",method=RequestMethod.GET)
	public List<Feedback> getFeedback(@PathVariable int pid)
	{
		List<Feedback> feedbacks=services.getFeedbacks(pid);
		return feedbacks;
		
	}

}
