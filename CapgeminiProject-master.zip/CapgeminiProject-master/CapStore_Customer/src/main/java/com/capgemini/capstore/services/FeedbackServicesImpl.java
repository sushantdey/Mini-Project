package com.capgemini.capstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Feedback;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.repo.CustomerRepo;
import com.capgemini.capstore.repo.FeedbackRepo;
import com.capgemini.capstore.repo.ProductRepo;

@Component
public class FeedbackServicesImpl implements FeedbackServices {

	
	@Autowired
	FeedbackRepo repo;
	
	@Autowired
	ProductRepo prepo;
	
	@Autowired
	CustomerRepo crepo;
	
	@Override
	public Feedback addFeedback(Feedback feedBack) {
	/*Product product=prepo.getOne(pid);
	Customer customer=crepo.getOne(cid);
	Feedback feedback=new Feedback();
	feedback.setFeedbackDesc(feedbackDesc);
	feedback.setCustomer(customer);
	feedback.setProduct(product);
	repo.save(feedback);
		return feedback;
	}*/
		repo.save(feedBack);
		return null;
	}

	@Override
	public List<Feedback> getFeedbacks(int pid) {
	
		return repo.findAll();
	}

}
