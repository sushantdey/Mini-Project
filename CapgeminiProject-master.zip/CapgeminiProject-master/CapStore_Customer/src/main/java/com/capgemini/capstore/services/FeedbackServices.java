package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.beans.Feedback;

public interface FeedbackServices {

	public Feedback addFeedback(Feedback feedBack);
	
	public List<Feedback> getFeedbacks(int pid);
}
