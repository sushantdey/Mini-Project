import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Friend } from 'src/app/friend';
import { CapBookService } from 'src/app/services/cap-book.service';
import { Router } from '@angular/router';
import { Profile } from 'src/app/profile';

@Component({
  selector: 'app-select-friend',
  templateUrl: './select-friend.component.html',
  styleUrls: ['./select-friend.component.css']
})
export class SelectFriendComponent implements OnInit {
  message:string;
  errorMessage:string;
  constructor(private capbookService:CapBookService,private router:Router) { }
  @Input() friend: Profile;

  @Output() sendMessageClicked: EventEmitter<string> = new EventEmitter<string>();
  
  onClick(): void{
    console.log(this.friend);
    sessionStorage.setItem('friend', JSON.stringify(this.friend));
      this.router.navigate(['/sendMessage']);
    /* this.capbookService.sendMessage(this.friend).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    ); */
  }
  ngOnInit() {
  }
}
