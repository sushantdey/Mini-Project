import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPlusComponent } from './user-plus.component';

describe('UserPlusComponent', () => {
  let component: UserPlusComponent;
  let fixture: ComponentFixture<UserPlusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserPlusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPlusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
