import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cap-book-home',
  templateUrl: './cap-book-home.component.html',
  styleUrls: ['./cap-book-home.component.css']
})
export class CapBookHomeComponent implements OnInit {
  title = 'CapBook';
  description='CapBook helps associates connect and share across people in Capgemini';
  constructor() { }

  ngOnInit() {
  }

}
