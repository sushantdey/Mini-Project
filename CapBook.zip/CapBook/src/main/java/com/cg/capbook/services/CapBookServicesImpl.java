package com.cg.capbook.services;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Profile;
import com.cg.capbook.daoservices.ProfileDAO;
import com.cg.capbook.exceptions.EmailAlreadyUsedException;
import com.cg.capbook.exceptions.InvalidEmailIdException;
import com.cg.capbook.exceptions.InvalidPasswordException;
@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices {
	@Autowired
	private ProfileDAO profileDAO;
	@Override
	public void registerUser(Profile profile) throws EmailAlreadyUsedException {
		if(profileDAO.findById(profile.getEmailId()).isPresent())
			throw new EmailAlreadyUsedException();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    Date today = new Date();
		profile.setDateOfJoining(formatter.format(today).toString());
		profileDAO.save(profile);
	}
	@Override
	public Profile loginUser(Profile profile) throws InvalidEmailIdException, InvalidPasswordException {
		Profile profile1=profileDAO.findById(profile.getEmailId()).orElseThrow(()->new InvalidEmailIdException());
		if(!profile.getPassword().equals(profile1.getPassword()))
			throw new InvalidPasswordException();
		return profile1;
	}
	@Override
	public Profile editProfile(Profile profile) throws InvalidEmailIdException {
		profileDAO.findById(profile.getEmailId()).orElseThrow(()->new InvalidEmailIdException());
		profile=profileDAO.editProfile(profile.getCurrentCity(),profile.getHighestEducation(),profile.getRelationshipStatus(),profile.getUserBio(),profile.getWorkPlace(),profile.getEmailId());
		/*if(profile.getFirstName()!=null)
			profile1.setFirstName(profile.getFirstName());
		if(profile.getLastName()!=null)
			profile1.setLastName(profile.getLastName());
		if(profile.getUserBio()!=null)
			profile1.setUserBio(profile.getUserBio());
		if(profile.getWorkPlace()!=null)
			profile1.setUserBio(profile.getUserBio());
		if(profile.getDateOfBirth()!=null)
			profile1.setDateOfBirth(profile.getDateOfBirth());
		if(profile.getGender()!=null)
			profile1.setGender(profile.getGender());
		if(profile.getRelationshipStatus()!=null)
			profile1.setRelationshipStatus(profile.getRelationshipStatus());
		if(profile.getAddress().getCurrentCity()!=null)
			profile1.getAddress().setCurrentCity(profile.getAddress().getCurrentCity());
		if(profile.getAddress().getHomeTown()!=null)
			profile1.getAddress().setHomeTown(profile.getAddress().getHomeTown());
		if(profile.getAddress().getState()!=null)
			profile1.getAddress().setState(profile.getAddress().getState());
		if(profile.getAddress().getCountry()!=null)
			profile1.getAddress().setCountry(profile.getAddress().getCountry());
		if(profile.getAddress().getPinCode()!=null)
			profile1.getAddress().setPinCode(profile.getAddress().getPinCode());
		if(profile.getEducation().getHighSchool()!=null)
			profile1.getEducation().setHighSchool(profile.getEducation().getHighSchool());
		if(profile.getEducation().getIntermediate()!=null)
			profile1.getEducation().setIntermediate(profile.getEducation().getIntermediate());
		if(profile.getEducation().getGraduation()!=null)
			profile1.getEducation().setGraduation(profile.getEducation().getGraduation());
		if(profile.getEducation().getPostGraduation()!=null)
			profile1.getEducation().setPostGraduation(profile.getEducation().getPostGraduation());*/
		return profile;
	}
}
